package com.ontariotechu.sofe3980U;

import org.joda.time.LocalTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.function.BiFunction;

/**
 * Binary Operations Program
 */
public class App {

    /**
     * Main program: Entry point of the program.
     * Displays the current time, prompts the user for two binary numbers,
     * and allows the user to choose an operation to perform on those numbers.
     *
     * @param args: not used
     */
    public static void main(String[] args) {
        // Display the current local time
        printCurrentTime();

        // Gather user input for binary numbers
        Binary binary1 = getBinaryInput("Please enter the first binary number:");
        Binary binary2 = getBinaryInput("Please enter the second binary number:");

        // Show available operations
        printOperationsMenu();

        // Get and perform the user's chosen operation
        performOperation(binary1, binary2);
        
        // Print a farewell message
        System.out.println("\nThank you for using the Binary Operations Program!");
    }

    /**
     * Prints the current local time.
     */
    private static void printCurrentTime() {
        LocalTime currentTime = new LocalTime();
        System.out.println("The current local time is: " + currentTime);
    }

    /**
     * Prompts the user to enter a binary number, creates a Binary object, and returns it.
     *
     * @param prompt the prompt to display to the user
     * @return a Binary object representing the user's input
     */
    private static Binary getBinaryInput(String prompt) {
        Scanner scanner = new Scanner(System.in);
        System.out.println(prompt);
        String userInput = scanner.nextLine();
        Binary binary = new Binary(userInput);
        System.out.println("Entered binary number: " + binary.getValue());
        return binary;
    }

    /**
     * Displays a menu of available operations for the user to choose from.
     */
    private static void printOperationsMenu() {
        System.out.println("\nChoose an operation:");
        System.out.println("1. OR");
        System.out.println("2. AND");
        System.out.println("3. Multiply");
        System.out.println("4. Add");
    }

    /**
     * Prompts the user for a choice and performs the corresponding binary operation.
     *
     * @param binary1 the first binary number
     * @param binary2 the second binary number
     */
    private static void performOperation(Binary binary1, Binary binary2) {
        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();

        // Create a map of operations
        Map<Integer, BiFunction<Binary, Binary, Binary>> operationsMap = new HashMap<>();
        operationsMap.put(1, Binary::or);
        operationsMap.put(2, Binary::and);
        operationsMap.put(3, Binary::multiply);
        operationsMap.put(4, Binary::add);

        // Perform the operation based on the user's choice
        if (operationsMap.containsKey(choice)) {
            Binary result = operationsMap.get(choice).apply(binary1, binary2);
            displayResult(choice, result);
        } else {
            System.out.println("Invalid choice. Please restart the program and try again.");
        }
    }

    /**
     * Displays the result of the operation based on the user's choice.
     *
     * @param choice the user's choice
     * @param result the result of the operation
     */
    private static void displayResult(int choice, Binary result) {
        String operation = switch (choice) {
            case 1 -> "OR";
            case 2 -> "AND";
            case 3 -> "Multiply";
            case 4 -> "Add";
            default -> "Unknown";
        };
        System.out.println("Result of " + operation + " operation: " + result.getValue());
    }
}