package com.ontariotechu.sofe3980U;

/**
 * Unsigned integer Binary variable
 *
 */
public class Binary {
    private String binaryString; // String containing the binary value '0' or '1'

    /**
     * A constructor that generates a binary object.
     *
     * @param binaryString a String of the binary values. It should contain only zeros or ones with any length and order.
     *                     Otherwise, the value of "0" will be stored. Trailing zeros will be excluded, and an empty string will be considered as zero.
     */
    public Binary(String binaryString) {
        this.binaryString = sanitizeBinaryString(binaryString);
    }

    /**
     * Sanitizes the input binary string.
     *
     * @param input the binary string to sanitize
     * @return a valid binary string
     */
    private String sanitizeBinaryString(String input) {
        if (input == null || input.isEmpty() || !input.matches("[01]*")) {
            return "0"; // Return "0" for null, empty, or invalid strings
        }
        // Remove leading zeros
        String sanitized = input.replaceFirst("^0+(?!$)", "");
        return sanitized.isEmpty() ? "0" : sanitized; // Return "0" if the sanitized string is empty
    }

    /**
     * Return the binary value of the variable
     *
     * @return the binary value in a string format.
     */
    public String getValue() {
        return this.binaryString;
    }

    /**
     * Adds two binary variables.
     *
     * @param firstBinary  The first addend object
     * @param secondBinary The second addend object
     * @return A binary variable with a value of <i>firstBinary + secondBinary</i>.
     */
    public static Binary add(Binary firstBinary, Binary secondBinary) {
        StringBuilder sumResult = new StringBuilder();
        int carry = 0;
        int maxLength = Math.max(firstBinary.binaryString.length(), secondBinary.binaryString.length());

        for (int i = 0; i < maxLength || carry != 0; i++) {
            int firstBit = (i < firstBinary.binaryString.length()) ? firstBinary.binaryString.charAt(firstBinary.binaryString.length() - 1 - i) - '0' : 0;
            int secondBit = (i < secondBinary.binaryString.length()) ? secondBinary.binaryString.charAt(secondBinary.binaryString.length() - 1 - i) - '0' : 0;

            int sum = firstBit + secondBit + carry;
            carry = sum / 2;
            sumResult.append(sum % 2);
        }

        return new Binary(sumResult.reverse().toString()); // Create a binary object with the calculated value
    }

    /**
     * Performs a bitwise OR operation on two binary variables.
     *
     * @param firstBinary  The first binary variable
     * @param secondBinary The second binary variable
     * @return A binary variable representing the bitwise OR result
     */
    public static Binary or(Binary firstBinary, Binary secondBinary) {
        int maxLength = Math.max(firstBinary.binaryString.length(), secondBinary.binaryString.length());
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < maxLength; i++) {
            char bit1 = (i < firstBinary.binaryString.length()) ? firstBinary.binaryString.charAt(i) : '0';
            char bit2 = (i < secondBinary.binaryString.length()) ? secondBinary.binaryString.charAt(i) : '0';
            result.append((bit1 == '1' || bit2 == '1') ? '1' : '0');
        }
        return new Binary(result.toString());
    }

    /**
     * Performs a bitwise AND operation on two binary variables.
     *
     * @param firstBinary  The first binary variable
     * @param secondBinary The second binary variable
     * @return A binary variable representing the bitwise AND result
     */
    public static Binary and(Binary firstBinary, Binary secondBinary) {
        int maxLength = Math.max(firstBinary.binaryString.length(), secondBinary.binaryString.length());
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < maxLength; i++) {
            char bit1 = (i < firstBinary.binaryString.length()) ? firstBinary.binaryString.charAt(i) : '0';
            char bit2 = (i < secondBinary.binaryString.length()) ? secondBinary.binaryString.charAt(i) : '0';
            result.append((bit1 == '1' && bit2 == '1') ? '1' : '0');
        }
        return new Binary(result.toString());
    }

    /**
     * Multiplies two binary variables.
     *
     * @param firstBinary  The first binary variable
     * @param secondBinary The second binary variable
     * @return A binary variable representing the product
     */
    public static Binary multiply(Binary firstBinary, Binary secondBinary) {
        int decimal1 = Integer.parseInt(firstBinary.binaryString, 2); // Convert binary1 to an integer
        int decimal2 = Integer.parseInt(secondBinary.binaryString, 2); // Convert binary2 to an integer
        int product = decimal1 * decimal2; // Multiply the integers
        return new Binary(Integer.toBinaryString(product)); // Convert the result back to binary
    }
}